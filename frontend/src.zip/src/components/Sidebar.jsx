import React, { useState } from "react";
import Home from '../assets/icons/home.png';
import User from '../assets/icons/user.png'
import Approval from '../assets/icons/approval.png'
import Settings from '../assets/icons/settings.png'
import Menu from '../assets/icons/menu.png'

export default function Sidebar() {
    const [isExpanded, setIsExpanded] = useState(false);

    const toggleSidebar = () => {
        setIsExpanded(!isExpanded);
    };

    return (
        <div
            className={`sidebar bg-black h-[100vh] font-roboto shadow-lg transition-all duration-300 ${isExpanded ? 'w-1/4' : 'w-16'}`}
        >
            <div className="sidebar-header flex  items-center border-b border-gray-700 px-5 py-6">
                <button onClick={toggleSidebar} className={`menu-icon w-8 h-8 transition-all duration-300 ${isExpanded ? 'rotate-90' : ''}`}>
                    <img src={Menu} alt="Menu" className="w-6 h-6 z-10" />
                </button>
                <div className={`sidebar-title mx-auto text-white text-3xl font-semibold transition-all duration-300 ${isExpanded ? 'block' : 'hidden'}`}>
                    <h2>HomeTour</h2>
                </div>
            </div>
            <div className="sidebar-menu">
                <ul className={`space-y-2 px-5 py-4  text-sm my-24 font-semibold ${isExpanded ? 'block' : 'hidden'}`}>
                    <li className="flex items-center w-full mx-auto hover:bg-gray-800  rounded-md transition duration-200 text-inherit">
                        <img className={`w-6 h-6 mr-4 ${isExpanded ? 'opacity-100' : 'opacity-0'}`} src={Home} alt="Home" />
                        <a href="/admin" className={`text-white hover:text-[#F9A826] block py-3 transition-opacity duration-300 ${isExpanded ? 'opacity-100' : 'opacity-0'}`}>Dashboard</a>
                    </li>
                    <li className="flex items-center hover:bg-gray-800 rounded-md transition duration-200 text-inherit">
                        <img className={`w-6 h-6 mr-4 ${isExpanded ? 'opacity-100' : 'opacity-0'}`} src={User} alt="Users" />
                        <a href="/admin/users" className={`text-white hover:text-[#F9A826] block py-3 transition-opacity duration-300 ${isExpanded ? 'opacity-100' : 'opacity-0'}`}>Manage Properties</a>
                    </li>
                    <li className="flex items-center hover:bg-gray-800 rounded-md transition duration-200 text-inherit">
                        <img className={`w-6 h-6 mr-4 ${isExpanded ? 'opacity-100' : 'opacity-0'}`} src={Approval} alt="Products" />
                        <a href="/admin/products" className={`text-white hover:text-[#F9A826] block py-3 transition-opacity duration-300 ${isExpanded ? 'opacity-100' : 'opacity-0'}`}>Properties Approval</a>
                    </li>
                    <li className="flex items-center hover:bg-gray-800 rounded-md transition duration-200 text-inherit">
                        <img className={`w-6 h-6 mr-4 ${isExpanded ? 'opacity-100' : 'opacity-0'}`} src={Settings} alt="Orders" />
                        <a href="/admin/orders" className={`text-white hover:text-[#F9A826] block py-3 transition-opacity duration-300 ${isExpanded ? 'opacity-100' : 'opacity-0'}`}>Orders</a>
                    </li>
                </ul>
            </div>
        </div>
    );
}